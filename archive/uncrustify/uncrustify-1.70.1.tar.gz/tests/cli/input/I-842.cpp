namespace Namespace
{
	// class Class {
		public void foo()
		{

		}
	}
}
