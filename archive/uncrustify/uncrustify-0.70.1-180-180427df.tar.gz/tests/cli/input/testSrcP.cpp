#define x s23_foo += \
s8_foo * s16_bar;

struct TelegramIndex
{
TelegramIndex(const char* pN, unsigned long nI) :
pTelName(pN),
nTelIndex(n)
{
}

~TelegramIndex()
{
}

const char* const pTelName;
unsigned long nTelIndex;
};

